<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "invoices".
 *
 * @property int $id
 * @property int $invoices_date
 * @property int $supply_date
 * @property string $comment
 */
class Invoices extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'invoices';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'invoices_date', 'supply_date', 'comment'], 'required'],
            [['id'], 'integer'],
            [['invoices_date', 'supply_date'], 'date', 'format'=>'yyyy-MM-dd'],
            [['comment'], 'string'],
            [['id'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'invoices_date' => 'Invoices Date',
            'supply_date' => 'Supply Date',
            'comment' => 'Comment',
        ];
    }
}
